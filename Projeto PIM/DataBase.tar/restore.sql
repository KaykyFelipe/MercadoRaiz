--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 16.3
-- Dumped by pg_dump version 16.3

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE fazendaurbana;
--
-- Name: fazendaurbana; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE fazendaurbana WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'Portuguese_Brazil.1252';


ALTER DATABASE fazendaurbana OWNER TO postgres;

\connect fazendaurbana

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: pg_database_owner
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO pg_database_owner;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: pg_database_owner
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: alterar_status(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.alterar_status() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
	BEGIN
		IF ((SELECT status FROM plantio WHERE NEW.id_plantio = plantio.id) = 'colhido') THEN
			DELETE FROM colheita_estoque WHERE id_colheita = NEW.id_colheita;
			RAISE EXCEPTION 'Esse plantio ja foi colhido';
		
		END IF;

		IF ((SELECT data_plantio FROM plantio WHERE NEW.id_plantio = plantio.id) >= NEW.data_colheita) THEN
			DELETE FROM colheita_estoque WHERE id_colheita = NEW.id_colheita;
			RAISE EXCEPTION 'O plantio está no futuro da colheita, corrija a data_colheita';

		END IF;

		UPDATE plantio
		SET status = 'colhido'
		WHERE id = NEW.id_plantio;

		RETURN NEW;
	END;
$$;


ALTER FUNCTION public.alterar_status() OWNER TO postgres;

--
-- Name: descontar_area(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.descontar_area() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    IF new.status = 'colhido' THEN
        UPDATE propriedade
        SET area_plantada = area_plantada - (SELECT area FROM plantio WHERE id = new.id)
        WHERE id = new.id_propriedade;
    END IF;
    RETURN new;
END;
$$;


ALTER FUNCTION public.descontar_area() OWNER TO postgres;

--
-- Name: descontar_quant(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.descontar_quant() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
	BEGIN
		
		UPDATE colheita_estoque
        SET quantidade = colheita_estoque.quantidade - NEW.quantidade
        
        FROM item_pedido
        WHERE colheita_estoque.id_colheita = NEW.id_estoque;
        

        RETURN NEW;
    END;
$$;


ALTER FUNCTION public.descontar_quant() OWNER TO postgres;

--
-- Name: somar_area(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.somar_area() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
	BEGIN
		IF (NEW.area > (SELECT (tamanho - area_plantada) FROM propriedade WHERE id = NEW.id_propriedade)) THEN
			DELETE FROM plantio WHERE id = NEW.id_propriedade;
			RAISE EXCEPTION 'Area a ser inserida maior que a disponivel para plantio';
			
		END IF;
		UPDATE propriedade
		SET area_plantada = area_plantada + NEW.area
		WHERE id = NEW.id_propriedade;

		RETURN NEW;
	END;
$$;


ALTER FUNCTION public.somar_area() OWNER TO postgres;

--
-- Name: somar_valor(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.somar_valor() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
    BEGIN
        
        UPDATE pedido_venda
        SET valor = pedido_venda.valor + ((SELECT preco_unitario FROM colheita_estoque WHERE colheita_estoque.id_colheita = NEW.id_estoque) * NEW.quantidade)
        FROM item_pedido, colheita_estoque
        WHERE pedido_venda.id = NEW.id_pedido;
                

        RETURN NEW;
    END;
$$;


ALTER FUNCTION public.somar_valor() OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: cliente; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.cliente (
    email character varying(90) NOT NULL,
    celular character varying(15) NOT NULL,
    nome character varying(90) NOT NULL,
    senha character varying(10) NOT NULL
);


ALTER TABLE public.cliente OWNER TO postgres;

--
-- Name: colheita_estoque; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.colheita_estoque (
    id_colheita integer NOT NULL,
    data_colheita timestamp without time zone NOT NULL,
    quantidade integer NOT NULL,
    preco_unitario numeric(10,2) NOT NULL,
    id_plantio integer,
    CONSTRAINT colheita_estoque_preco_unitario_check CHECK ((preco_unitario > (0)::numeric)),
    CONSTRAINT quantidade_check CHECK ((quantidade >= 0))
);


ALTER TABLE public.colheita_estoque OWNER TO postgres;

--
-- Name: colheita_estoque_id_colheita_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.colheita_estoque_id_colheita_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.colheita_estoque_id_colheita_seq OWNER TO postgres;

--
-- Name: colheita_estoque_id_colheita_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.colheita_estoque_id_colheita_seq OWNED BY public.colheita_estoque.id_colheita;


--
-- Name: pedido_venda; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.pedido_venda (
    id integer NOT NULL,
    data timestamp without time zone NOT NULL,
    valor numeric(12,2) DEFAULT 0.00,
    email_cliente character varying(90),
    CONSTRAINT pedido_venda_valor_check CHECK ((valor >= (0)::numeric))
);


ALTER TABLE public.pedido_venda OWNER TO postgres;

--
-- Name: head_pedido; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.head_pedido AS
 SELECT pv.id AS pedido,
    EXTRACT(DAY FROM pv.data) AS dia,
    EXTRACT(MONTH FROM pv.data) AS mes,
    EXTRACT(YEAR FROM pv.data) AS ano,
    c.nome AS nome_cliente
   FROM (public.pedido_venda pv
     JOIN public.cliente c ON (((c.email)::text = (pv.email_cliente)::text)));


ALTER VIEW public.head_pedido OWNER TO postgres;

--
-- Name: plantio; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.plantio (
    id integer NOT NULL,
    data_plantio timestamp without time zone NOT NULL,
    area integer NOT NULL,
    id_propriedade integer,
    id_prodagricola integer,
    status character varying(30) DEFAULT 'plantado'::character varying,
    CONSTRAINT plantio_check CHECK ((area > 0)),
    CONSTRAINT plantio_status_check CHECK (((status)::text = ANY ((ARRAY['plantado'::character varying, 'colhido'::character varying])::text[])))
);


ALTER TABLE public.plantio OWNER TO postgres;

--
-- Name: prodagricola; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.prodagricola (
    id integer NOT NULL,
    nome character varying(255) NOT NULL
);


ALTER TABLE public.prodagricola OWNER TO postgres;

--
-- Name: info_colheita; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.info_colheita AS
 SELECT ce.id_colheita,
    pl.data_plantio,
    ce.data_colheita,
    agr.nome AS prod_agricola,
    pl.area AS area_m2,
    ce.quantidade,
    (ce.quantidade / pl.area) AS rendimento,
    ce.preco_unitario
   FROM ((public.colheita_estoque ce
     JOIN public.plantio pl ON ((pl.id = ce.id_plantio)))
     JOIN public.prodagricola agr ON ((agr.id = pl.id_prodagricola)));


ALTER VIEW public.info_colheita OWNER TO postgres;

--
-- Name: propriedade; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.propriedade (
    id integer NOT NULL,
    tamanho integer NOT NULL,
    rua character varying(90) NOT NULL,
    numero integer,
    bairro character varying(40),
    cidade character varying(40) NOT NULL,
    estado character varying(2),
    email_proprietario character varying(90),
    tipo character varying(20),
    area_plantada integer,
    CONSTRAINT propriedade_check CHECK (((area_plantada <= tamanho) AND (area_plantada >= 0))),
    CONSTRAINT propriedade_tipo_check CHECK (((tipo)::text = ANY ((ARRAY['HIDROPONIA'::character varying, 'TRADICIONAL'::character varying])::text[])))
);


ALTER TABLE public.propriedade OWNER TO postgres;

--
-- Name: info_plantio; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.info_plantio AS
 SELECT pl.id,
    prop.tamanho,
    prop.tipo,
    prop.area_plantada,
    agr.nome AS prod_agricola,
    pl.area AS area_m2,
    pl.data_plantio
   FROM ((public.plantio pl
     JOIN public.propriedade prop ON ((prop.id = pl.id_propriedade)))
     JOIN public.prodagricola agr ON ((agr.id = pl.id_prodagricola)));


ALTER VIEW public.info_plantio OWNER TO postgres;

--
-- Name: item_pedido; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.item_pedido (
    id integer NOT NULL,
    quantidade integer NOT NULL,
    id_estoque integer,
    id_pedido integer,
    CONSTRAINT item_pedido_quantidade_check CHECK ((quantidade >= 0))
);


ALTER TABLE public.item_pedido OWNER TO postgres;

--
-- Name: item_pedido_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.item_pedido_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.item_pedido_id_seq OWNER TO postgres;

--
-- Name: item_pedido_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.item_pedido_id_seq OWNED BY public.item_pedido.id;


--
-- Name: pedido; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.pedido AS
 SELECT ip.id_pedido,
    ip.quantidade,
    ic.prod_agricola AS produto,
    ic.preco_unitario,
    ((ip.quantidade)::numeric * ic.preco_unitario) AS valor
   FROM (public.item_pedido ip
     JOIN public.info_colheita ic ON ((ic.id_colheita = ip.id_estoque)))
  ORDER BY ip.id_pedido;


ALTER VIEW public.pedido OWNER TO postgres;

--
-- Name: pedido_venda_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.pedido_venda_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.pedido_venda_id_seq OWNER TO postgres;

--
-- Name: pedido_venda_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.pedido_venda_id_seq OWNED BY public.pedido_venda.id;


--
-- Name: plantio_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.plantio_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.plantio_id_seq OWNER TO postgres;

--
-- Name: plantio_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.plantio_id_seq OWNED BY public.plantio.id;


--
-- Name: prodagricola_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.prodagricola_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.prodagricola_id_seq OWNER TO postgres;

--
-- Name: prodagricola_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.prodagricola_id_seq OWNED BY public.prodagricola.id;


--
-- Name: produtor; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.produtor (
    email character varying(90) NOT NULL,
    celular character varying(15) NOT NULL,
    nome character varying(30) NOT NULL,
    senha character varying(10) NOT NULL,
    chave_pix character varying(255)
);


ALTER TABLE public.produtor OWNER TO postgres;

--
-- Name: propriedade_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.propriedade_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.propriedade_id_seq OWNER TO postgres;

--
-- Name: propriedade_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.propriedade_id_seq OWNED BY public.propriedade.id;


--
-- Name: vitrine_venda; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.vitrine_venda AS
 SELECT ce.id_colheita,
    to_char(pl.data_plantio, 'DD-MM-YY'::text) AS plantio,
    to_char(ce.data_colheita, 'DD-MM-YY'::text) AS colheita,
    agr.nome AS prod_agricola,
    pl.area AS area_m2,
    ce.quantidade,
    (ce.quantidade / pl.area) AS rendimento,
    ce.preco_unitario,
    p.nome AS produtor,
    pr.tipo,
    pr.cidade
   FROM ((((public.colheita_estoque ce
     JOIN public.plantio pl ON ((pl.id = ce.id_plantio)))
     JOIN public.prodagricola agr ON ((agr.id = pl.id_prodagricola)))
     JOIN public.propriedade pr ON ((pr.id = pl.id_propriedade)))
     JOIN public.produtor p ON (((p.email)::text = (pr.email_proprietario)::text)))
  WHERE (ce.quantidade <> 0);


ALTER VIEW public.vitrine_venda OWNER TO postgres;

--
-- Name: colheita_estoque id_colheita; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.colheita_estoque ALTER COLUMN id_colheita SET DEFAULT nextval('public.colheita_estoque_id_colheita_seq'::regclass);


--
-- Name: item_pedido id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.item_pedido ALTER COLUMN id SET DEFAULT nextval('public.item_pedido_id_seq'::regclass);


--
-- Name: pedido_venda id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pedido_venda ALTER COLUMN id SET DEFAULT nextval('public.pedido_venda_id_seq'::regclass);


--
-- Name: plantio id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.plantio ALTER COLUMN id SET DEFAULT nextval('public.plantio_id_seq'::regclass);


--
-- Name: prodagricola id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.prodagricola ALTER COLUMN id SET DEFAULT nextval('public.prodagricola_id_seq'::regclass);


--
-- Name: propriedade id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.propriedade ALTER COLUMN id SET DEFAULT nextval('public.propriedade_id_seq'::regclass);


--
-- Data for Name: cliente; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.cliente (email, celular, nome, senha) FROM stdin;
\.
COPY public.cliente (email, celular, nome, senha) FROM '$$PATH$$/4938.dat';

--
-- Data for Name: colheita_estoque; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.colheita_estoque (id_colheita, data_colheita, quantidade, preco_unitario, id_plantio) FROM stdin;
\.
COPY public.colheita_estoque (id_colheita, data_colheita, quantidade, preco_unitario, id_plantio) FROM '$$PATH$$/4947.dat';

--
-- Data for Name: item_pedido; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.item_pedido (id, quantidade, id_estoque, id_pedido) FROM stdin;
\.
COPY public.item_pedido (id, quantidade, id_estoque, id_pedido) FROM '$$PATH$$/4951.dat';

--
-- Data for Name: pedido_venda; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.pedido_venda (id, data, valor, email_cliente) FROM stdin;
\.
COPY public.pedido_venda (id, data, valor, email_cliente) FROM '$$PATH$$/4949.dat';

--
-- Data for Name: plantio; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.plantio (id, data_plantio, area, id_propriedade, id_prodagricola, status) FROM stdin;
\.
COPY public.plantio (id, data_plantio, area, id_propriedade, id_prodagricola, status) FROM '$$PATH$$/4945.dat';

--
-- Data for Name: prodagricola; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.prodagricola (id, nome) FROM stdin;
\.
COPY public.prodagricola (id, nome) FROM '$$PATH$$/4943.dat';

--
-- Data for Name: produtor; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.produtor (email, celular, nome, senha, chave_pix) FROM stdin;
\.
COPY public.produtor (email, celular, nome, senha, chave_pix) FROM '$$PATH$$/4939.dat';

--
-- Data for Name: propriedade; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.propriedade (id, tamanho, rua, numero, bairro, cidade, estado, email_proprietario, tipo, area_plantada) FROM stdin;
\.
COPY public.propriedade (id, tamanho, rua, numero, bairro, cidade, estado, email_proprietario, tipo, area_plantada) FROM '$$PATH$$/4941.dat';

--
-- Name: colheita_estoque_id_colheita_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.colheita_estoque_id_colheita_seq', 15, true);


--
-- Name: item_pedido_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.item_pedido_id_seq', 5, true);


--
-- Name: pedido_venda_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.pedido_venda_id_seq', 2, true);


--
-- Name: plantio_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.plantio_id_seq', 32, true);


--
-- Name: prodagricola_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.prodagricola_id_seq', 19, true);


--
-- Name: propriedade_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.propriedade_id_seq', 9, true);


--
-- Name: cliente cliente_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cliente
    ADD CONSTRAINT cliente_pkey PRIMARY KEY (email);


--
-- Name: colheita_estoque colheita_estoque_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.colheita_estoque
    ADD CONSTRAINT colheita_estoque_pkey PRIMARY KEY (id_colheita);


--
-- Name: item_pedido item_pedido_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.item_pedido
    ADD CONSTRAINT item_pedido_pkey PRIMARY KEY (id);


--
-- Name: pedido_venda pedido_venda_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pedido_venda
    ADD CONSTRAINT pedido_venda_pkey PRIMARY KEY (id);


--
-- Name: plantio plantio_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.plantio
    ADD CONSTRAINT plantio_pkey PRIMARY KEY (id);


--
-- Name: prodagricola prodagricola_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.prodagricola
    ADD CONSTRAINT prodagricola_pkey PRIMARY KEY (id);


--
-- Name: produtor produtor_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.produtor
    ADD CONSTRAINT produtor_pkey PRIMARY KEY (email);


--
-- Name: propriedade propriedade_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.propriedade
    ADD CONSTRAINT propriedade_pkey PRIMARY KEY (id);


--
-- Name: plantio atualizar_area_plantada; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER atualizar_area_plantada AFTER INSERT ON public.plantio FOR EACH ROW EXECUTE FUNCTION public.somar_area();


--
-- Name: colheita_estoque atualizar_status_plantio; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER atualizar_status_plantio AFTER INSERT ON public.colheita_estoque FOR EACH ROW EXECUTE FUNCTION public.alterar_status();


--
-- Name: item_pedido descontar_area_plantada; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER descontar_area_plantada AFTER INSERT ON public.item_pedido FOR EACH ROW EXECUTE FUNCTION public.descontar_quant();


--
-- Name: plantio descontar_area_plantada; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER descontar_area_plantada AFTER UPDATE ON public.plantio FOR EACH ROW EXECUTE FUNCTION public.descontar_area();


--
-- Name: item_pedido somar_valor_pedido; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER somar_valor_pedido AFTER INSERT ON public.item_pedido FOR EACH ROW EXECUTE FUNCTION public.somar_valor();


--
-- Name: colheita_estoque colheita_estoque_id_plantio_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.colheita_estoque
    ADD CONSTRAINT colheita_estoque_id_plantio_fkey FOREIGN KEY (id_plantio) REFERENCES public.plantio(id);


--
-- Name: item_pedido item_pedido_id_estoque_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.item_pedido
    ADD CONSTRAINT item_pedido_id_estoque_fkey FOREIGN KEY (id_estoque) REFERENCES public.colheita_estoque(id_colheita);


--
-- Name: item_pedido item_pedido_id_pedido_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.item_pedido
    ADD CONSTRAINT item_pedido_id_pedido_fkey FOREIGN KEY (id_pedido) REFERENCES public.pedido_venda(id);


--
-- Name: pedido_venda pedido_venda_email_cliente_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pedido_venda
    ADD CONSTRAINT pedido_venda_email_cliente_fkey FOREIGN KEY (email_cliente) REFERENCES public.cliente(email);


--
-- Name: plantio plantio_id_prodagricola_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.plantio
    ADD CONSTRAINT plantio_id_prodagricola_fkey FOREIGN KEY (id_prodagricola) REFERENCES public.prodagricola(id);


--
-- Name: plantio plantio_id_propriedade_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.plantio
    ADD CONSTRAINT plantio_id_propriedade_fkey FOREIGN KEY (id_propriedade) REFERENCES public.propriedade(id);


--
-- Name: propriedade propriedade_email_proprietario_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.propriedade
    ADD CONSTRAINT propriedade_email_proprietario_fkey FOREIGN KEY (email_proprietario) REFERENCES public.produtor(email);


--
-- PostgreSQL database dump complete
--

